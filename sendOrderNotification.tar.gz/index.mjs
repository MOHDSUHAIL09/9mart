/* eslint-env node */
import nodemailer from 'nodemailer';

export default async ({ req, res, log }) => {
  try {
    const rawEventData = process.env.APPWRITE_FUNCTION_EVENT_DATA;

    if (!rawEventData) {
      log("❌ APPWRITE_FUNCTION_EVENT_DATA is missing.");
      return res.send("No event data provided.");
    }

    const payload = JSON.parse(rawEventData);
    log("✅ Payload received:", payload);

    const document = payload.payload;

    if (!document || !document.userEmail) {
      log("❌ userEmail not found in payload.");
      return res.send("Missing userEmail in the event payload.");
    }

    const recipientEmail = document.userEmail;
    const orderId = document.$id || "unknown";

    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT),
      secure: Number(process.env.SMTP_PORT) === 465,
      requireTLS: true,
      auth: {
        user: process.env.SMTP_USERNAME,
        pass: process.env.SMTP_PASSWORD
      }
    });

    try {
      await transporter.verify();
      log("✅ SMTP server is ready to take messages");
    } catch (verifyError) {
      log("❌ SMTP Verification failed:", verifyError.message);
      return res.send("SMTP connection error: " + verifyError.message);
    }

    log("📨 Sending email...");
    const info = await transporter.sendMail({
      from: `"xomart" <${process.env.FROM_EMAIL}>`,
      to: recipientEmail,
      subject: `Order Confirmation: ${orderId}`,
      text: `Thank you! Your order ID is ${orderId}.`
    });

    log(`✅ Email sent successfully: ${info.messageId}`);
    return res.send(`Email sent to ${recipientEmail}`);
  } catch (error) {
    log("❌ Error sending email:", error.message);
    return res.send("Function failed: " + error.message);
  }
};
