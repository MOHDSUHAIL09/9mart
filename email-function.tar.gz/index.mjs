
import nodemailer from 'nodemailer';

export default async ({ log, error, env }) => {
  try {
    const payload = JSON.parse(env.APPWRITE_FUNCTION_EVENT_DATA);
    const orderId = payload?.$id || 'N/A';

    const transporter = nodemailer.createTransport({
      host: env.SMTP_HOST,
      port: parseInt(env.SMTP_PORT),
      secure: false,
      auth: {
        user: env.SMTP_USERNAME,
        pass: env.SMTP_PASSWORD
      }
    });

    const mailOptions = {
      from: env.FROM_EMAIL,
      to: env.TO_EMAIL,
      subject: `🛒 New Order Received - ID: ${orderId}`,
      text: `You have received a new order.\n\nOrder ID: ${orderId}\n\nDetails:\n${JSON.stringify(payload, null, 2)}`
    };

    const info = await transporter.sendMail(mailOptions);
    log(`✅ Email sent: ${info.response}`);

    return { status: 'Email sent successfully' };
  } catch (err) {
    error('❌ Error sending email:', err);
    return { status: 'Error', message: err.message };
  }
};
