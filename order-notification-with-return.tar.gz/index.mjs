import nodemailer from "nodemailer";

export default async function ({ req, res, log, error }) {
  try {
    const payload = JSON.parse(process.env.APPWRITE_FUNCTION_EVENT_DATA || '{}');

    const orderId = payload.$id;
    const customerName = payload.name || 'Customer';
    const customerEmail = payload.email || 'Unknown';

    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: parseInt(process.env.SMTP_PORT),
      secure: true,
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS
      }
    });

    await transporter.sendMail({
      from: `"Order Notification" <${process.env.SMTP_USER}>`,
      to: process.env.TO_EMAIL,
      subject: `🛒 New Order Received: ${orderId}`,
      text: `You received a new order from ${customerName} (${customerEmail}).\n\nOrder ID: ${orderId}`
    });

    return res.send("Email sent successfully!");
  } catch (err) {
    error("Failed to send email: " + err.message);
    return res.send("Failed to send email");
  }
}