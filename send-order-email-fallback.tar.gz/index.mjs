import nodemailer from "nodemailer";

export default async function ({ req, res, log, error }) {
  try {
    const payload = JSON.parse(process.env.APPWRITE_FUNCTION_EVENT_DATA || '{}');

    const orderId = payload.$id;
    const productName = payload.productName || "Unknown Product";
    const price = payload.price || 0;
    const quantity = payload.quantity || 0;
    const paymentStatus = payload.paymentStatus || "N/A";
    const customerEmail = payload.userEmail || process.env.TO_EMAIL;
    const imageUrl = payload.imageUrl || "";
    const timestamp = payload.timestamp || "";

    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: parseInt(process.env.SMTP_PORT),
      secure: true,
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS
      }
    });

    const htmlContent = `
      <h2>🛒 Order Confirmation</h2>
      <p>Thank you for your order!</p>
      <ul>
        <li><strong>Product:</strong> ${productName}</li>
        <li><strong>Quantity:</strong> ${quantity}</li>
        <li><strong>Price:</strong> ₹${price}</li>
        <li><strong>Total:</strong> ₹${price * quantity}</li>
        <li><strong>Payment Status:</strong> ${paymentStatus}</li>
        <li><strong>Order ID:</strong> ${orderId}</li>
        <li><strong>Date:</strong> ${timestamp}</li>
      </ul>
      ${imageUrl ? `<img src="${imageUrl}" alt="Product Image" width="200"/>` : ""}
    `;

    await transporter.sendMail({
      from: `"Order Notification" <${process.env.SMTP_USER}>`,
      to: customerEmail,
      subject: `🛒 Order Confirmation: ${orderId}`,
      html: htmlContent
    });

    return res.send("Email sent successfully!");
  } catch (err) {
    error("Failed to send email: " + err.message);
    return res.send("Failed to send email");
  }
}
